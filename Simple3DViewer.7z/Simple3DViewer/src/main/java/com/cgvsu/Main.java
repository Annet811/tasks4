package com.cgvsu;

public class Main {
    public static void main(String[] args) {

        Simple3DViewer.main(args);
    }
}
